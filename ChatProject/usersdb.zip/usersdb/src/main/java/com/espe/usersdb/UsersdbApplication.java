package com.espe.usersdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsersdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsersdbApplication.class, args);
	}

}
