package com.espe.chatsdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatsdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
