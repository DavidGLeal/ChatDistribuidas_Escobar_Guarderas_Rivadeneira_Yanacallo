package com.espe.socket_chat.socket_chat.model;

public enum MessageType {

    CHAT,
    JOIN,
    NOTIFICATION, LEAVE
}
