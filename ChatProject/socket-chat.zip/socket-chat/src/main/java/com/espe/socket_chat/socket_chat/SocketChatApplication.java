package com.espe.socket_chat.socket_chat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocketChatApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocketChatApplication.class, args);
	}

}
