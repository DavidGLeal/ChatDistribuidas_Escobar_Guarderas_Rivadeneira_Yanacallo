package com.espe.chat_socket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatSocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
