package com.espe.chat_socket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatSocketApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatSocketApplication.class, args);
	}

}
